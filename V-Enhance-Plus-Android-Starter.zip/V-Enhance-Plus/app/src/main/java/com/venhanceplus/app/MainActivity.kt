package com.venhanceplus.app

import android.net.Uri
import android.os.Bundle
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

private val Ink = Color(0xFF090B14)
private val Panel = Color(0xFF151A2B)
private val Purple = Color(0xFF8B5CF6)
private val Cyan = Color(0xFF35D6D0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VEnhanceApp() }
    }
}

@Composable
private fun VEnhanceApp() {
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var selectedFilter by remember { mutableStateOf("Original") }
    var intensity by remember { mutableFloatStateOf(70f) }
    var resolution by remember { mutableStateOf("1080p") }
    var language by remember { mutableStateOf("English") }
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
        videoUri = it
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Ink, surface = Panel, primary = Purple,
            secondary = Cyan, onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(containerColor = Ink) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).background(
                    Brush.verticalGradient(listOf(Color(0xFF17152E), Ink, Ink))
                ).padding(horizontal = 18.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(46.dp).background(
                            Brush.linearGradient(listOf(Purple, Cyan)),
                            RoundedCornerShape(15.dp)
                        ), contentAlignment = Alignment.Center
                    ) {
                        Text("V", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("V Enhance Plus", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text("OFFLINE VIDEO STUDIO", color = Color(0xFFAAA9C4), fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                    Icon(Icons.Rounded.WifiOff, contentDescription = "Offline", tint = Cyan)
                }

                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("Make every frame", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                    Text("look its best.", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = Purple)
                    Text("Enhance, style and export your videos on your device.",
                        color = Color(0xFFB5B6C8), fontSize = 13.sp)
                }

                Card(colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        if (videoUri == null) {
                            Box(
                                Modifier.fillMaxWidth().height(190.dp)
                                    .background(Color(0xFF20243A), RoundedCornerShape(16.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Rounded.VideoLibrary, null, tint = Purple, modifier = Modifier.size(42.dp))
                                    Spacer(Modifier.height(8.dp))
                                    Text("Your video preview", fontWeight = FontWeight.SemiBold)
                                    Text("Choose a video to get started", color = Color.LightGray, fontSize = 12.sp)
                                }
                            }
                        } else {
                            AndroidView(
                                factory = { ctx ->
                                    VideoView(ctx).apply {
                                        setVideoURI(videoUri)
                                        setOnPreparedListener { it.isLooping = true; start() }
                                    }
                                },
                                update = { view ->
                                    if (view.tag != videoUri) {
                                        view.tag = videoUri
                                        view.setVideoURI(videoUri)
                                        view.setOnPreparedListener { it.isLooping = true; view.start() }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(210.dp)
                            )
                        }
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = { picker.launch("video/*") },
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Purple),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Rounded.Add, null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (videoUri == null) "Import video" else "Change video", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                SectionTitle("QUICK FILTERS", "12+ looks")
                val filters = listOf("Original", "Cinematic", "Golden", "Vintage", "Cool Blue", "Vivid", "B&W", "Pastel", "Moody", "Natural", "Drama", "Sunset")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    filters.forEach { name ->
                        FilterChip(
                            selected = selectedFilter == name,
                            onClick = { selectedFilter = name },
                            label = { Text(name) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Purple, selectedLabelColor = Color.White,
                                containerColor = Panel, labelColor = Color(0xFFD4D4E2)
                            )
                        )
                    }
                }
                Text("Filter intensity  •  ${intensity.toInt()}%", color = Color(0xFFE4E3F0), fontWeight = FontWeight.SemiBold)
                Slider(value = intensity, onValueChange = { intensity = it }, valueRange = 0f..100f)

                SectionTitle("EXPORT QUALITY", "On-device")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("720p", "1080p", "2K").forEach { size ->
                        val chosen = resolution == size
                        OutlinedButton(
                            onClick = { resolution = size },
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (chosen) Purple.copy(alpha = .22f) else Panel,
                                contentColor = if (chosen) Color.White else Color.LightGray
                            ),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp, if (chosen) Purple else Color(0xFF34384E)
                            )
                        ) { Text(size, fontWeight = FontWeight.Bold) }
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Coming in the processing engine", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("AI upscaling • Denoise • Detail recovery • Color grading",
                            color = Color(0xFFB5B6C8), fontSize = 12.sp)
                        Text("This starter build provides the app shell and video selection/preview. AI processing and real export are the next development phase.",
                            color = Color(0xFFFFD28A), fontSize = 11.sp)
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Language", color = Color.LightGray, modifier = Modifier.weight(1f))
                    TextButton(onClick = { language = if (language == "English") "বাংলা" else "English" }) {
                        Text(language, color = Cyan)
                    }
                }
                Spacer(Modifier.height(18.dp))
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, trailing: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color(0xFFE8E7F5), fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, modifier = Modifier.weight(1f))
        Text(trailing, color = Purple, fontSize = 11.sp)
    }
}
