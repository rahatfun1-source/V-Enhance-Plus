# V Enhance Plus — Android starter project

This is **Phase 1 (UI foundation)** of the V Enhance Plus Android app.

## Included
- Kotlin + Jetpack Compose premium dark UI
- Android video picker (system picker; no broad storage permission)
- Basic video preview
- Filter selection UI and intensity control
- Export resolution selection UI (720p / 1080p / 2K)
- Offline-first app shell; no Internet permission is declared

## Not implemented yet
- Real-time video filter rendering
- AI enhancement / Real-ESRGAN model integration
- Video transcoding and MP4 export
- Audio/timestamp preservation pipeline

The UI does not claim these unfinished functions are already active. They are planned for subsequent phases.

## Build
Requirements: Android Studio with JDK 17 and Android SDK 35.

1. Open this folder in Android Studio.
2. Allow Gradle sync to finish.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK output: `app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions
The workflow at `.github/workflows/android.yml` builds a debug APK on push and allows manual runs.
